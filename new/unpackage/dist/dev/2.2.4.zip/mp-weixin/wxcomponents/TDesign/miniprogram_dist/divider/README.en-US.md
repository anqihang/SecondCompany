:: BASE_DOC ::

## API
### Divider Props

name | type | default | description | required
-- | -- | -- | -- | --
align | String | center | options：left/right/center | N
content | String / Slot | - | \- | N
dashed | Boolean | false | \- | N
external-classes | Array | - | `['t-class', 't-class-line', 't-class-content']` | N
layout | String | horizontal | options：horizontal/vertical | N
