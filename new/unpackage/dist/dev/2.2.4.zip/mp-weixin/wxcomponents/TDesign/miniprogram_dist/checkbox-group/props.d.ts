import { TdCheckboxGroupProps } from './type';
declare const props: TdCheckboxGroupProps;
export default props;
