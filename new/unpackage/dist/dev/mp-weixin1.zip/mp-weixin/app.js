"use strict";
Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
const common_vendor = require("./common/vendor.js");
require("./utils/request.js");
if (!Math) {
  "./pages/index/index.js";
  "./pages/home/home.js";
  "./pages/article/article.js";
  "./pages/category/category.js";
  "./pages/video/video.js";
  "./pages_details/article_details/article_details.js";
  "./pages_details/SearchList/SearchList.js";
  "./pages_details/video_details/video_details.js";
}
const __default__ = {
  onLaunch: function() {
    console.log("App Launch");
    common_vendor.wx$1.hideShareMenu({
      menus: ["shareTimeline"]
    });
  },
  onShow: function() {
    console.log("App Show");
    common_vendor.index.hideTabBar({
      animation: false
    });
  },
  onLoad: function() {
    console.log("App Load");
  },
  onHide: function() {
    console.log("App Hide");
  }
};
const _sfc_main = /* @__PURE__ */ Object.assign(__default__, {
  __name: "App",
  setup(__props) {
    const model = common_vendor.ref("");
    const appId = common_vendor.ref("");
    common_vendor.onLaunch(() => {
      common_vendor.index.getSystemInfo({
        success(e) {
          model.value = e.osName;
          common_vendor.provide("model", model);
        }
      });
      appId.value = common_vendor.wx$1.getAccountInfoSync().miniProgram.appId;
      common_vendor.provide("appId", appId);
    });
    return () => {
    };
  }
});
const App = /* @__PURE__ */ common_vendor._export_sfc(_sfc_main, [["__file", "C:/Users/Administrator/Desktop/new(1)/new/App.vue"]]);
function createApp() {
  const app = common_vendor.createSSRApp(App);
  return {
    app
  };
}
createApp().app.mount("#app");
exports.createApp = createApp;
