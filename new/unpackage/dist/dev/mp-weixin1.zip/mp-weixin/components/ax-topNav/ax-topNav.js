"use strict";
const common_vendor = require("../../common/vendor.js");
const __default__ = {
  name: "ax-topNav",
  data() {
    return {};
  }
};
const _sfc_main = /* @__PURE__ */ Object.assign(__default__, {
  props: ["back", "name", "isShare", "backPage"],
  setup(__props) {
    const props = __props;
    let type = common_vendor.ref("");
    common_vendor.onLoad(() => {
      common_vendor.index.getSystemInfo({
        success(e) {
          type.value = e.osName;
        }
      });
    });
    function f_navBack() {
      if (props.isShare) {
        common_vendor.index.switchTab({
          url: props.backPage
        });
      } else {
        common_vendor.index.navigateBack();
      }
    }
    return (_ctx, _cache) => {
      return common_vendor.e({
        a: common_vendor.t(props.name),
        b: common_vendor.unref(type) == "ios" ? "24rpx" : "36rpx",
        c: props.back + "" != "undefined"
      }, props.back + "" != "undefined" ? {
        d: common_vendor.o(f_navBack)
      } : {});
    };
  }
});
const Component = /* @__PURE__ */ common_vendor._export_sfc(_sfc_main, [["__file", "C:/Users/Administrator/Desktop/new(1)/new/components/ax-topNav/ax-topNav.vue"]]);
wx.createComponent(Component);
