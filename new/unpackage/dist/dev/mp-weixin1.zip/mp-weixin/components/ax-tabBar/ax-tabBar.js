"use strict";
const common_vendor = require("../../common/vendor.js");
const utils_api = require("../../utils/api.js");
require("../../utils/request.js");
const __default__ = {
  name: "ax-tabBar",
  data() {
    return {};
  }
};
const _sfc_main = /* @__PURE__ */ Object.assign(__default__, {
  props: ["name"],
  setup(__props) {
    const props = __props;
    const appId = common_vendor.inject("appId");
    let type = common_vendor.ref("");
    common_vendor.onLoad(() => {
      common_vendor.index.getSystemInfo({
        success(e) {
          type.value = e.osName;
        }
      });
      f_getAdv({ appId: appId.value });
    });
    const list = common_vendor.ref([
      { id: 1, title: "美文", url: "/pages/article/article", icon: "/static/icon/article" },
      { id: 2, title: "美文分类", url: "/pages/category/category", icon: "/static/icon/category" }
    ]);
    function f_navTo(url) {
      common_vendor.index.switchTab({
        url
      });
    }
    const videoAble = common_vendor.ref(false);
    function f_getAdv(o) {
      utils_api.Adv(o).then((res) => {
        res.advertPlaceConfigs.forEach((element) => {
          if (element.title == "config_vid") {
            videoAble.value = true;
          }
        });
        if (videoAble.value) {
          console.log("11");
          list.value.unshift({ id: 3, title: "视频", url: "/pages/video/video", icon: "/static/icon/video" });
        }
      });
    }
    return (_ctx, _cache) => {
      return {
        a: common_vendor.f(list.value, (item, index, i0) => {
          return common_vendor.e({
            a: props.name == item.title
          }, props.name == item.title ? {
            b: item.icon + "1.png"
          } : {
            c: item.icon + ".png"
          }, {
            d: common_vendor.t(item.title),
            e: props.name == item.title ? "red" : "#000",
            f: common_vendor.o(($event) => f_navTo(item.url), index),
            g: index
          });
        }),
        b: common_vendor.unref(type) == "ios" ? "20rpx" : "24rpx",
        c: common_vendor.unref(type) == "ios" ? "164rpx" : "110rpx"
      };
    };
  }
});
const Component = /* @__PURE__ */ common_vendor._export_sfc(_sfc_main, [["__file", "C:/Users/Administrator/Desktop/new(1)/new/components/ax-tabBar/ax-tabBar.vue"]]);
wx.createComponent(Component);
