"use strict";
const common_vendor = require("../../common/vendor.js");
if (!Array) {
  const _easycom_ax_topNav2 = common_vendor.resolveComponent("ax-topNav");
  const _easycom_ax_tabBar2 = common_vendor.resolveComponent("ax-tabBar");
  (_easycom_ax_topNav2 + _easycom_ax_tabBar2)();
}
const _easycom_ax_topNav = () => "../../components/ax-topNav/ax-topNav.js";
const _easycom_ax_tabBar = () => "../../components/ax-tabBar/ax-tabBar.js";
if (!Math) {
  (_easycom_ax_topNav + _easycom_ax_tabBar)();
}
const __default__ = {
  data() {
    return {};
  }
};
const _sfc_main = /* @__PURE__ */ Object.assign(__default__, {
  __name: "home",
  setup(__props) {
    common_vendor.inject("appId");
    const list = common_vendor.ref([{ id: 0, title: "aadfsd" }, { id: 1, title: "fffffa" }, { id: 2, title: "dsfsadfasf" }]);
    return (_ctx, _cache) => {
      return {
        a: common_vendor.p({
          name: "首页"
        }),
        b: common_vendor.f(list.value, (item, index, i0) => {
          return {
            a: item.id
          };
        }),
        c: common_vendor.p({
          name: "首页"
        })
      };
    };
  }
});
const MiniProgramPage = /* @__PURE__ */ common_vendor._export_sfc(_sfc_main, [["__file", "C:/Users/Administrator/Desktop/new(1)/new/pages/home/home.vue"]]);
wx.createPage(MiniProgramPage);
