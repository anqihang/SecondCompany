"use strict";
const common_vendor = require("../../common/vendor.js");
require("../../utils/request.js");
const __default__ = {
  data() {
    return {
      title: "Hello"
    };
  },
  onLoad() {
  },
  methods: {}
};
const _sfc_main = /* @__PURE__ */ Object.assign(__default__, {
  __name: "index",
  setup(__props) {
    const appId = common_vendor.inject("appId");
    function login() {
      common_vendor.wx$1.showLoading({
        title: "登录中"
      });
      return new Promise((resolve, reject) => {
        common_vendor.wx$1.login({
          success: function(res) {
            if (res.code) {
              common_vendor.index.request({
                url: "https://xcx.wujingchuanmei.com/api/xcx/login",
                // url: "http://192.168.2.135:8093/api/xcx/login",
                method: "post",
                data: {
                  code: res.code,
                  appId: appId.value
                },
                success: (res2) => {
                  common_vendor.wx$1.hideLoading();
                  const data = res2.data;
                  common_vendor.index.setStorageSync("token", data.token);
                  resolve("success");
                }
              });
            }
          }
        });
      });
    }
    const path = common_vendor.ref(null);
    const type = common_vendor.ref(null);
    common_vendor.onLoad((options) => {
      common_vendor.index.hideTabBar({
        animation: false
      });
      appId.value = common_vendor.wx$1.getAccountInfoSync().miniProgram.appId;
      let s = JSON.stringify(options).replace(/,/g, "&").replace(/"/g, "").replace(/:/g, "=").replace(/{/, "").replace(/}/, "");
      path.value = options.path || null;
      type.value = options.type || "tabBar";
      if (!path.value) {
        path.value = "/pages/article/article";
      }
      login().then((res) => {
        if (type.value == "tabBar") {
          common_vendor.index.switchTab({
            url: path.value
          });
        } else {
          common_vendor.index.redirectTo({
            url: path.value + "?" + s
          });
        }
      });
    });
    common_vendor.onMounted(() => {
    });
    return (_ctx, _cache) => {
      return {};
    };
  }
});
const MiniProgramPage = /* @__PURE__ */ common_vendor._export_sfc(_sfc_main, [["__file", "C:/Users/Administrator/Desktop/new(1)/new/pages/index/index.vue"]]);
wx.createPage(MiniProgramPage);
