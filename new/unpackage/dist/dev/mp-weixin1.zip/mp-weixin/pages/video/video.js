"use strict";
const common_vendor = require("../../common/vendor.js");
const utils_api = require("../../utils/api.js");
const utils_adv = require("../../utils/adv.js");
require("../../utils/request.js");
if (!Array) {
  const _easycom_ax_topNav2 = common_vendor.resolveComponent("ax-topNav");
  const _component_t_image = common_vendor.resolveComponent("t-image");
  const _component_t_divider = common_vendor.resolveComponent("t-divider");
  const _easycom_ax_tabBar2 = common_vendor.resolveComponent("ax-tabBar");
  (_easycom_ax_topNav2 + _component_t_image + _component_t_divider + _easycom_ax_tabBar2)();
}
const _easycom_ax_topNav = () => "../../components/ax-topNav/ax-topNav.js";
const _easycom_ax_tabBar = () => "../../components/ax-tabBar/ax-tabBar.js";
if (!Math) {
  (_easycom_ax_topNav + _easycom_ax_tabBar)();
}
const __default__ = {
  data() {
    return {};
  }
};
const _sfc_main = /* @__PURE__ */ Object.assign(__default__, {
  __name: "video",
  setup(__props) {
    const appId = common_vendor.inject("appId");
    const navList = common_vendor.ref([
      // {
      // 	id: 0,
      // 	name: '精彩集锦',
      // },
      // {
      // 	id: 1,
      // 	name: '推荐阅读',
      // },
      // {
      // 	id: 2,
      // 	name: '正能量',
      // },
      // {
      // 	id: 3,
      // 	name: '美文',
      // },
      // {
      // 	id: 4,
      // 	name: '祝福',
      // },
    ]);
    let select = common_vendor.ref(-1);
    const list = common_vendor.ref([
      // {
      // 	id: 0,
      // 	title: '早上好，中午好，晚上好，一天问三次。icon图片大小为81px，title为三行射手是是是是射手是是是是是是是是',
      // 	time: '2023-5-8',
      // 	img: '/static/li.png',
      // },
      // {
      // 	id: 1,
      // 	title: '早上好，中午好，晚上好，一天问三次。icon图片大小为81px，title为三行',
      // 	time: '2023-5-8',
      // 	img: '/static/li.png',
      // },
      // {
      // 	id: 2,
      // 	title: '早上好，中午好，晚上好，一天问三次。icon图片大小为81px，title为三行',
      // 	time: '2023-5-8',
      // 	img: '/static/li.png',
      // },
      // {
      // 	id: 3,
      // 	title: '早上好，中午好，晚上好，一天问三次。icon图片大小为81px，title为三行',
      // 	time: '2023-5-8',
      // 	img: '/static/li.png',
      // },
      // {
      // 	id: 4,
      // 	title: '早上好，中午好，晚上好，一天问三次。icon图片大小为81px，title为三行',
      // 	time: '2023-5-8',
      // 	img: '/static/li.png',
      // },
      // {
      // 	id: 5,
      // 	title: '早上好，中午好，晚上好，一天问三次。icon图片大小为81px，title为三行',
      // 	time: '2023-5-8',
      // 	img: '/static/li.png',
      // },
      // {
      // 	id: 5,
      // 	title: '早上好，中午好，晚上好，一天问三次。icon图片大小为81px，title为三行',
      // 	time: '2023-5-8',
      // 	img: '/static/li.png',
      // },
      // {
      // 	id: 5,
      // 	title: '早上好，中午好，晚上好，一天问三次。icon图片大小为81px，title为三行',
      // 	time: '2023-5-10',
      // 	img: '/static/li.png',
      // },
    ]);
    const page = common_vendor.ref(1);
    const newsObject = common_vendor.ref({
      appId: appId.value,
      page: page.value,
      type: null
    });
    const buttom = common_vendor.ref(false);
    const refresh = common_vendor.ref(true);
    function f_getVideoList(o) {
      utils_api.videoList(o).then((data) => {
        console.log("videoList", data);
        if (data.videoList.length > 0) {
          data.videoList.forEach((item) => {
            console.log(item.icon, "2222");
            item.icon = item.icon.split(",")[0];
          });
        }
        if (data.videoList.length < 10) {
          refresh.value = false;
        }
        if (buttom.value) {
          list.value = list.value.concat(data.videoList);
          buttom.value = false;
        } else {
          console.log(111111);
          list.value = data.videoList;
        }
      });
    }
    function f_getItems(o) {
      utils_api.getVideoItems(o).then((res) => {
        navList.value = res.xcxVideoTypeList;
      });
    }
    function f_changeSelect(item) {
      select.value = item.id;
      if (item.id == -1) {
        newsObject.value.type = null;
      } else {
        newsObject.value.type = item.id;
      }
      refresh.value = true;
      page.value = 1;
      f_getVideoList(newsObject.value);
    }
    const adv = common_vendor.ref({
      status: null,
      every: null,
      advId: null,
      type: null
    });
    const advC = common_vendor.ref({
      status: null,
      advId: null,
      intervalNum: null
    });
    const timer = common_vendor.ref(null);
    let interstitialAd = null;
    function showAdv1() {
      interstitialAd.show().then(() => {
        console.log("插屏广告显示中，不再定时拉取广告");
      }).catch((err) => {
        console.error(err);
      });
    }
    const createAdv1 = function() {
      if (common_vendor.wx$1.createInterstitialAd) {
        interstitialAd = common_vendor.wx$1.createInterstitialAd({
          adUnitId: advC.value.advId
        });
        interstitialAd.onLoad(() => {
          console.log("onLoad event emit");
        });
        interstitialAd.onError((err) => {
          console.log("onError event emit", err);
        });
        interstitialAd.onClose((res) => {
          console.log("插屏广告已关闭，重新开始定时拉取");
          if (!timer) {
            timer.value = setInterval(() => {
              console.log(2);
              showAdv1();
            }, advC.value.intervalNum * 1e3);
          }
          console.log("onClose event emit", res);
        });
        timer.value = setInterval(() => {
          console.log(1);
          showAdv1();
          clearInterval(timer.value);
        }, 2 * 1e3);
      }
    };
    function f_getAdv(o) {
      utils_api.Adv(o).then((res) => {
        let type = null;
        res.advertPlaceConfigs.forEach((element) => {
          if (element.title == "config_vid") {
            type = element.advertTypeId;
            adv.value.status = element.status;
            adv.value.every = element.acticleCnt;
            adv.value.type = element.advertTypeId;
          }
        });
        res.advertTypes.forEach((element) => {
          if (type == element.type) {
            adv.value.advId = element.content.trim();
          }
          if (element.type == 2) {
            advC.value.status = element.status;
            advC.value.advId = element.content.trim();
            advC.value.intervalNum = element.intervalNum;
          }
        });
        console.log(adv.value);
        if (advC.value.status) {
          createAdv1();
        }
      });
    }
    common_vendor.onShow(() => {
      f_getAdv({
        appId: appId.value
      });
      common_vendor.wx$1.hideShareMenu({
        menus: ["shareTimeline"]
      });
    });
    common_vendor.onHide(() => {
      utils_adv.clearTimer();
      clearInterval(timer.value);
      interstitialAd = null;
    });
    common_vendor.onUnload(() => {
      utils_adv.clearTimer();
      clearInterval(timer.value);
      interstitialAd = null;
    });
    common_vendor.onMounted(() => {
      f_getItems({
        appId: appId.value
      });
    });
    common_vendor.onLoad((res) => {
      newsObject.value.type = res.id;
      common_vendor.index.hideTabBar({
        animation: false
      });
      f_getVideoList(newsObject.value);
    });
    function f_go(item) {
      common_vendor.index.navigateTo({
        url: "/pages_details/video_details/video_details?id=" + item.id
      });
    }
    function f_touchBottom(e) {
      if (refresh.value) {
        buttom.value = true;
        page.value += 1;
        f_getVideoList({
          appId: appId.value,
          page: page.value,
          type: newsObject.value.type
        });
      }
    }
    common_vendor.onShareAppMessage(() => {
      return {
        title: "",
        path: "/pages/index/index?path=/pages/video/video&type=tabBar&share=true&id=" + newsObject.value.type
      };
    });
    return (_ctx, _cache) => {
      return {
        a: common_vendor.p({
          name: "视频"
        }),
        b: common_vendor.unref(select) == -1 ? 1 : "",
        c: common_vendor.o(($event) => f_changeSelect({
          id: -1
        })),
        d: common_vendor.f(navList.value, (item, index, i0) => {
          return {
            a: common_vendor.t(item == null ? void 0 : item.title),
            b: item.id == common_vendor.unref(select) ? 1 : "",
            c: index,
            d: common_vendor.o(($event) => f_changeSelect(item), index)
          };
        }),
        e: common_vendor.f(list.value, (item, index, i0) => {
          return common_vendor.e({
            a: "3347c3b4-1-" + i0,
            b: common_vendor.p({
              src: "https://xcx.wujingchuanmei.com/api" + item.icon,
              mode: "aspectFill",
              shape: "round",
              ariaLabel: "img"
            }),
            c: common_vendor.t(item == null ? void 0 : item.title),
            d: common_vendor.o(($event) => f_go(item), index),
            e: adv.value.status == 1 && adv.value.advId && adv.value.every != 0 && index != 0 && (index + 1) % adv.value.every == 0 && adv.value.type == 1
          }, adv.value.status == 1 && adv.value.advId && adv.value.every != 0 && index != 0 && (index + 1) % adv.value.every == 0 && adv.value.type == 1 ? {
            f: adv.value.advId
          } : {}, {
            g: adv.value.status == 1 && adv.value.advId && adv.value.every != 0 && index != 0 && (index + 1) % adv.value.every == 0 && adv.value.type == 3
          }, adv.value.status == 1 && adv.value.advId && adv.value.every != 0 && index != 0 && (index + 1) % adv.value.every == 0 && adv.value.type == 3 ? {
            h: adv.value.advId
          } : {}, {
            i: index
          });
        }),
        f: common_vendor.p({
          dashed: true,
          content: "已无更多数据"
        }),
        g: common_vendor.o(f_touchBottom),
        h: common_vendor.p({
          name: "视频"
        })
      };
    };
  }
});
const MiniProgramPage = /* @__PURE__ */ common_vendor._export_sfc(_sfc_main, [["__file", "C:/Users/Administrator/Desktop/new(1)/new/pages/video/video.vue"]]);
_sfc_main.__runtimeHooks = 6;
wx.createPage(MiniProgramPage);
