"use strict";
const common_vendor = require("../../common/vendor.js");
const utils_api = require("../../utils/api.js");
const utils_adv = require("../../utils/adv.js");
require("../../utils/request.js");
if (!Array) {
  const _easycom_ax_topNav2 = common_vendor.resolveComponent("ax-topNav");
  const _component_t_search = common_vendor.resolveComponent("t-search");
  const _component_t_divider = common_vendor.resolveComponent("t-divider");
  const _easycom_ax_tabBar2 = common_vendor.resolveComponent("ax-tabBar");
  (_easycom_ax_topNav2 + _component_t_search + _component_t_divider + _easycom_ax_tabBar2)();
}
const _easycom_ax_topNav = () => "../../components/ax-topNav/ax-topNav.js";
const _easycom_ax_tabBar = () => "../../components/ax-tabBar/ax-tabBar.js";
if (!Math) {
  (_easycom_ax_topNav + _easycom_ax_tabBar)();
}
const __default__ = {
  data() {
    return {};
  }
};
const _sfc_main = /* @__PURE__ */ Object.assign(__default__, {
  __name: "category",
  setup(__props) {
    const appId = common_vendor.inject("appId");
    const search = common_vendor.ref("");
    const categoryList = common_vendor.ref([
      // { id: 0, name: '分类1' },
      // { id: 1, name: '分类2' },
      // { id: 2, name: '分类3' },
      // { id: 3, name: '分类4' },
      // { id: 4, name: '分类5' },
      // { id: 4, name: '分类5' },
      // { id: 4, name: '分类5' },
      // { id: 4, name: '分类5' },
      // { id: 4, name: '分类5' },
      // { id: 4, name: '分类5' },
      // { id: 4, name: '分类5' },
      // { id: 4, name: '分类5' },
      // { id: 4, name: '分类5' },
      // { id: 4, name: '分类5' },
      // { id: 4, name: '分类5' },
      // { id: 4, name: '分类5' },
      // { id: 4, name: '分类5' },
      // { id: 4, name: '分类5' },
      // { id: 4, name: '分类5' },
      // { id: 4, name: '分类5' },
      // { id: 4, name: '分类5' },
      // { id: 4, name: '分类5' },
      // { id: 4, name: '分类5' },
      // { id: 4, name: '分类5' },
      // { id: 4, name: '分类5' },
      // { id: 4, name: '分类5' },
      // { id: 4, name: '分类5' },
      // { id: 4, name: '分类5' },
      // { id: 4, name: '分类5' },
      // { id: 4, name: '分类5' },
      // { id: 4, name: '分类5' },
      // { id: 4, name: '分类7' },
    ]);
    function f_getCategoryItems(o) {
      utils_api.categoryItems(o).then((data) => {
        console.log("getCityItems", data);
        categoryList.value = data.articleCateList;
      });
    }
    const advC = common_vendor.ref({
      status: null,
      advId: null,
      intervalNum: null
    });
    const timer = common_vendor.ref(null);
    let interstitialAd = null;
    function showAdv1() {
      interstitialAd.show().then(() => {
        console.log("插屏广告显示中，不再定时拉取广告");
      }).catch((err) => {
        console.error(err);
      });
    }
    const createAdv1 = function() {
      if (common_vendor.wx$1.createInterstitialAd) {
        interstitialAd = common_vendor.wx$1.createInterstitialAd({
          adUnitId: advC.value.advId
        });
        interstitialAd.onLoad(() => {
          console.log("onLoad event emit");
        });
        interstitialAd.onError((err) => {
          console.log("onError event emit", err);
        });
        interstitialAd.onClose((res) => {
          console.log("插屏广告已关闭，重新开始定时拉取");
          if (!timer) {
            timer.value = setInterval(() => {
              console.log(2);
              showAdv1();
            }, advC.value.intervalNum * 1e3);
          }
          console.log("onClose event emit", res);
        });
        timer.value = setInterval(() => {
          console.log(1);
          showAdv1();
          clearInterval(timer.value);
        }, advC.value.intervalNum * 1e3);
      }
    };
    function getAdv() {
      utils_api.Adv({
        appId: appId.value
      }).then((res) => {
        res.advertPlaceConfigs.forEach((element) => {
        });
        res.advertTypes.forEach((element) => {
          if (element.type == 2) {
            advC.value.status = element.status;
            advC.value.advId = element.content.trim();
            advC.value.intervalNum = element.intervalNum;
          }
        });
        if (advC.value.status) {
          createAdv1();
        }
      });
    }
    common_vendor.onShow(() => {
      getAdv({
        appId: appId.value
      });
      common_vendor.wx$1.hideShareMenu({
        menus: ["shareTimeline"]
      });
    });
    common_vendor.onHide(() => {
      utils_adv.clearTimer();
      clearInterval(timer.value);
      interstitialAd = null;
    });
    common_vendor.onUnload(() => {
      utils_adv.clearTimer();
      clearInterval(timer.value);
      interstitialAd = null;
    });
    common_vendor.onLoad(() => {
      common_vendor.index.hideTabBar({
        animation: false
      });
      f_getCategoryItems({
        appId: appId.value
        // type: 2,
      });
    });
    common_vendor.onMounted(() => {
    });
    function f_goSearchList(item) {
      common_vendor.index.navigateTo({
        url: "/pages_details/SearchList/SearchList?name=" + item.title + "&id=" + item.id + "&typeId=" + item.type
      });
    }
    function f_search(e) {
      search.value = e.detail.value;
      common_vendor.index.navigateTo({
        url: "/pages_details/SearchList/SearchList?name=&id=" + null + "&search=" + search.value
      });
    }
    common_vendor.onShareAppMessage(() => {
      return {
        title: "",
        path: "/pages/index/index?path=/pages/category/category&type=tabBar&share=true"
      };
    });
    return (_ctx, _cache) => {
      return {
        a: common_vendor.p({
          name: "美文分类"
        }),
        b: common_vendor.o(($event) => f_search($event)),
        c: common_vendor.p({
          value: search.value,
          placeholder: "请输入搜索内容/关键字",
          shape: "round"
        }),
        d: common_vendor.f(categoryList.value, (item, index, i0) => {
          return {
            a: common_vendor.t(index + 1),
            b: common_vendor.t(item.title),
            c: index,
            d: common_vendor.o(($event) => f_goSearchList(item), index)
          };
        }),
        e: common_vendor.p({
          dashed: true,
          content: "已无更多数据"
        }),
        f: common_vendor.p({
          name: "美文分类"
        })
      };
    };
  }
});
const MiniProgramPage = /* @__PURE__ */ common_vendor._export_sfc(_sfc_main, [["__file", "C:/Users/Administrator/Desktop/new(1)/new/pages/category/category.vue"]]);
_sfc_main.__runtimeHooks = 6;
wx.createPage(MiniProgramPage);
