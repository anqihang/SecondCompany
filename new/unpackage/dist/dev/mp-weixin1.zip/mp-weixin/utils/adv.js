"use strict";
require("../common/vendor.js");
let timer = null;
let timer1 = null;
const clearTimer = function() {
  clearInterval(timer);
  clearInterval(timer1);
};
exports.clearTimer = clearTimer;
