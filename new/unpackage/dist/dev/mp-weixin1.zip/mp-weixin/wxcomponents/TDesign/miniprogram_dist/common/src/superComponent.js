export class SuperComponent {
    constructor() {
        this.app = getApp();
    }
}
