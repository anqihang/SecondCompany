"use strict";
const common_vendor = require("../../common/vendor.js");
const utils_api = require("../../utils/api.js");
require("../../utils/request.js");
if (!Array) {
  const _easycom_ax_topNav2 = common_vendor.resolveComponent("ax-topNav");
  const _component_t_icon = common_vendor.resolveComponent("t-icon");
  const _component_t_image = common_vendor.resolveComponent("t-image");
  const _easycom_ax_tabBar2 = common_vendor.resolveComponent("ax-tabBar");
  (_easycom_ax_topNav2 + _component_t_icon + _component_t_image + _easycom_ax_tabBar2)();
}
const _easycom_ax_topNav = () => "../../components/ax-topNav/ax-topNav.js";
const _easycom_ax_tabBar = () => "../../components/ax-tabBar/ax-tabBar.js";
if (!Math) {
  (_easycom_ax_topNav + _easycom_ax_tabBar)();
}
const __default__ = {
  data() {
    return {};
  }
};
const _sfc_main = /* @__PURE__ */ Object.assign(__default__, {
  __name: "article_details",
  setup(__props) {
    common_vendor.inject("model");
    const appId = common_vendor.inject("appId");
    common_vendor.inject("pathDefault");
    const title = common_vendor.ref("");
    const updataTime = common_vendor.ref("");
    const content = common_vendor.ref("");
    const num = common_vendor.ref({
      read: 0,
      like: 0
    });
    const id = common_vendor.ref(null);
    function f_getNewInfo(o) {
      utils_api.newInfo(o).then((data) => {
        title.value = data.article.title;
        updataTime.value = data.article.createTime;
        content.value = data.article.content;
        num.value.read = data.article.readCnt;
        num.value.like = data.article.likeCnt;
        isLike.value = data.article.liked;
        suggestList.value = data.recommends;
        if (suggestList.length > 0) {
          suggestList.value.forEach((item) => {
            if (item.picPath) {
              item.picPath = item.picPath.split(",")[0];
            }
          });
        }
      });
    }
    const isLike = common_vendor.ref(false);
    const suggestList = common_vendor.ref([
      // {
      // 	id: 0,
      // 	img: '/static/li.png',
      // 	title: '文范德萨发的是范德萨范德萨发的说法是哒',
      // },
      // {
      // 	id: 0,
      // 	img: '/static/li.png',
      // 	title: '文范德萨发的是范德萨范德萨发的说法是哒',
      // },
    ]);
    const isFromShare = common_vendor.ref(false);
    const backPage = common_vendor.ref(null);
    const pagesArr = common_vendor.ref(null);
    pagesArr.value = getCurrentPages();
    common_vendor.onLoad((res) => {
      if (res.share) {
        isFromShare.value = true;
        backPage.value = res.backPage;
      } else {
        isFromShare.value = false;
        backPage.value = null;
      }
      id.value = res.id - 0;
      f_getNewInfo({
        id: id.value,
        appId: appId.value
      });
    });
    const advT = common_vendor.ref({
      status: null,
      every: null,
      advId: null,
      type: null
    });
    const advB = common_vendor.ref({
      status: null,
      every: null,
      advId: null,
      type: null
    });
    const advC = common_vendor.ref({
      status: null,
      advId: null,
      intervalNum: null
    });
    const timer = common_vendor.ref(null);
    let interstitialAd = null;
    function showAdv1() {
      interstitialAd.show().then(() => {
      }).catch((err) => {
        console.error(err);
      });
    }
    const createAdv1 = function() {
      if (common_vendor.wx$1.createInterstitialAd) {
        interstitialAd = common_vendor.wx$1.createInterstitialAd({
          adUnitId: advC.value.advId
        });
        interstitialAd.onLoad(() => {
          console.log("onLoad event emit");
        });
        interstitialAd.onError((err) => {
          console.log("onError event emit", err);
        });
        interstitialAd.onClose((res) => {
          console.log("插屏广告已关闭，重新开始定时拉取");
          if (!timer) {
            timer.value = setInterval(() => {
              showAdv1();
            }, advC.value.intervalNum * 1e3);
          }
          console.log("onClose event emit", res);
        });
        timer.value = setInterval(() => {
          showAdv1();
          clearInterval(timer.value);
        }, advC.value.intervalNum * 1e3);
      }
    };
    function f_getAdv(o) {
      utils_api.Adv(o).then((res) => {
        let typeT = null;
        let typeB = null;
        res.advertPlaceConfigs.forEach((element) => {
          if (element.title == "top_adv") {
            typeT = element.advertTypeId;
            advT.value.status = element.status;
            advT.value.every = element.acticleCnt;
            advT.value.type = element.advertTypeId;
          }
          if (element.title == "bottom_adv") {
            typeB = element.advertTypeId;
            advB.value.status = element.status;
            advB.value.every = element.acticleCnt;
            advB.value.type = element.advertTypeId;
          }
        });
        res.advertTypes.forEach((element) => {
          if (typeT == element.type) {
            advT.value.advId = element.content.trim();
          }
          if (typeB == element.type) {
            advB.value.advId = element.content.trim();
          }
          if (element.type == 2) {
            advC.value.status = element.status;
            advC.value.advId = element.content.trim();
            advC.value.intervalNum = element.intervalNum;
          }
        });
        if (advC.value.status) {
          createAdv1();
        }
      });
    }
    common_vendor.onShow(() => {
      f_getAdv({
        appId: appId.value
      });
      common_vendor.wx$1.hideShareMenu({
        menus: ["shareTimeline"]
      });
    });
    common_vendor.onHide(() => {
      clearInterval(timer.value);
      interstitialAd = null;
    });
    common_vendor.onUnload(() => {
      clearInterval(timer.value);
      interstitialAd = null;
    });
    common_vendor.onMounted(() => {
    });
    function f_like(o) {
      utils_api.like(o).then((data) => {
        if (data.code == 200) {
          isLike.value = true;
        }
      });
    }
    function f_cancelLike(o) {
      utils_api.cancelLike(o).then((data) => {
        if (data.code == 200) {
          isLike.value = false;
        }
      });
    }
    function f_up() {
      if (isLike.value) {
        f_cancelLike({
          id: id.value,
          appId: appId.value
        });
        num.value.like -= 1;
      } else {
        f_like({
          id: id.value,
          appId: appId.value
        });
        num.value.like += 1;
      }
    }
    common_vendor.ref(false);
    common_vendor.ref("");
    common_vendor.ref(null);
    const showAll = common_vendor.ref(false);
    function f_showAll() {
      showAll.value = true;
    }
    const scrollTop = common_vendor.ref(null);
    const oldScrollTop = common_vendor.ref(null);
    function f_scroll(e) {
      oldScrollTop.value = e.detail.scrollTop;
    }
    function f_refresh(item) {
      f_getNewInfo({
        id: item.id,
        appId: appId.value
      });
      scrollTop.value = oldScrollTop.value;
      let timer2 = setTimeout(() => {
        scrollTop.value = 0;
        clearTimeout(timer2);
      }, 100);
    }
    getCurrentPages();
    common_vendor.onShareAppMessage(() => {
      return {
        title: title.value,
        path: "/pages/index/index?path=/pages_details/article_details/article_details&type=noTabBar&share=true&backPage=/pages/article/article&id=" + id.value
      };
    });
    return (_ctx, _cache) => {
      return common_vendor.e({
        a: common_vendor.p({
          name: title.value,
          back: true,
          isShare: isFromShare.value,
          backPage: backPage.value
        }),
        b: advT.value.status == 1 && advT.value.advId && advT.value.type == 3
      }, advT.value.status == 1 && advT.value.advId && advT.value.type == 3 ? {
        c: advT.value.advId
      } : {}, {
        d: advT.value.status == 1 && advT.value.advId && advT.value.type == 1
      }, advT.value.status == 1 && advT.value.advId && advT.value.type == 1 ? {
        e: advT.value.advId
      } : {}, {
        f: common_vendor.t(title.value),
        g: common_vendor.t(updataTime.value),
        h: content.value,
        i: common_vendor.t(num.value.read),
        j: isLike.value ? "red" : "",
        k: common_vendor.p({
          name: "thumb-up",
          size: "40rpx"
        }),
        l: common_vendor.o(f_up),
        m: common_vendor.t(num.value.like),
        n: showAll.value ? "unset" : "500rpx",
        o: !showAll.value ? "0 4rpx 4rpx 4rpx #d8d8d8" : "unset",
        p: !showAll.value
      }, !showAll.value ? {
        q: common_vendor.o(f_showAll)
      } : {}, {
        r: common_vendor.p({
          name: "logo-wechat",
          size: "48rpx"
        }),
        s: common_vendor.p({
          name: "logo-wechat",
          size: "48rpx"
        }),
        t: advB.value.status == 1 && advB.value.advId && advB.value.type == 3
      }, advB.value.status == 1 && advB.value.advId && advB.value.type == 3 ? {
        v: advB.value.advId
      } : {}, {
        w: advB.value.status == 1 && advB.value.advId && advB.value.type == 1
      }, advB.value.status == 1 && advB.value.advId && advB.value.type == 1 ? {
        x: advB.value.advId
      } : {}, {
        y: suggestList.value.length > 0
      }, suggestList.value.length > 0 ? {
        z: common_vendor.f(suggestList.value, (item, index, i0) => {
          return {
            a: "15e7ecb3-4-" + i0,
            b: common_vendor.p({
              src: "https://xcx.wujingchuanmei.com/api" + item.picPath,
              mode: "aspectFill",
              shape: "round",
              ariaLabel: "img"
            }),
            c: common_vendor.t(item.title),
            d: common_vendor.o(($event) => f_refresh(item), index),
            e: index
          };
        })
      } : {}, {
        A: scrollTop.value,
        B: common_vendor.o(f_scroll),
        C: common_vendor.p({
          name: "美文"
        })
      });
    };
  }
});
const MiniProgramPage = /* @__PURE__ */ common_vendor._export_sfc(_sfc_main, [["__file", "C:/Users/Administrator/Desktop/new(1)/new/pages_details/article_details/article_details.vue"]]);
_sfc_main.__runtimeHooks = 6;
wx.createPage(MiniProgramPage);
