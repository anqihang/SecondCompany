"use strict";
const common_vendor = require("../../common/vendor.js");
const utils_api = require("../../utils/api.js");
const utils_adv = require("../../utils/adv.js");
require("../../utils/request.js");
if (!Array) {
  const _easycom_ax_topNav2 = common_vendor.resolveComponent("ax-topNav");
  const _component_txv_video = common_vendor.resolveComponent("txv-video");
  const _component_t_icon = common_vendor.resolveComponent("t-icon");
  const _component_t_image = common_vendor.resolveComponent("t-image");
  const _easycom_ax_tabBar2 = common_vendor.resolveComponent("ax-tabBar");
  (_easycom_ax_topNav2 + _component_txv_video + _component_t_icon + _component_t_image + _easycom_ax_tabBar2)();
}
const _easycom_ax_topNav = () => "../../components/ax-topNav/ax-topNav.js";
const _easycom_ax_tabBar = () => "../../components/ax-tabBar/ax-tabBar.js";
if (!Math) {
  (_easycom_ax_topNav + _easycom_ax_tabBar)();
}
const __default__ = {
  data() {
    return {};
  },
  mounted() {
  }
};
const _sfc_main = /* @__PURE__ */ Object.assign(__default__, {
  __name: "video_details",
  setup(__props) {
    common_vendor.inject("model");
    const appId = common_vendor.inject("appId");
    const title = common_vendor.ref("");
    const updataTime = common_vendor.ref("");
    common_vendor.ref(null);
    const num = common_vendor.ref({
      read: 0,
      like: 0
    });
    const id = common_vendor.ref(null);
    const isLike = common_vendor.ref(false);
    const suggestList = common_vendor.ref([
      // {
      // 	id: 0,
      // 	img: '/static/li.png',
      // 	title: '文范德萨发的是范德萨范德萨发的说法是哒fffffffffffadfas对方撒是的发放时大大师傅士大夫士大夫地方萨芬撒旦撒旦发射点',
      // },
      // {
      // 	id: 0,
      // 	img: '/static/li.png',
      // 	title: '文范德萨发的是范德萨范德萨发的说法是哒',
      // },
      // {
      // 	id: 0,
      // 	img: '/static/li.png',
      // 	title: '文范德萨发的是范德萨范德萨发的说法是哒',
      // },
      // {
      // 	id: 0,
      // 	img: '/static/li.png',
      // 	title: '文范德萨发的是范德萨范德萨发的说法是哒',
      // },
      // {
      // 	id: 0,
      // 	img: '/static/li.png',
      // 	title: '文范德萨发的是范德萨范德萨发的说法是哒',
      // },
      // {
      // 	id: 0,
      // 	img: '/static/li.png',
      // 	title: '文范德萨发的是范德萨范德萨发的说法是哒',
      // },
      // {
      // 	id: 0,
      // 	img: '/static/li.png',
      // 	title: '文范德萨发的是范德萨范德萨发的说法是哒',
      // },
      // {
      // 	id: 0,
      // 	img: '/static/li.png',
      // 	title: '文范德萨发的是范德萨范德萨发的说法是哒',
      // },
    ]);
    const isFromShare = common_vendor.ref(false);
    const backPage = common_vendor.ref(null);
    const vid = common_vendor.ref("");
    const videoSrc = common_vendor.ref(null);
    const sign = common_vendor.ref(true);
    const rewardAdv = common_vendor.ref(null);
    const advReward = common_vendor.ref({
      time: 0,
      title: "",
      id: "",
      status: 0
    });
    const popupVisible = common_vendor.ref(false);
    const agreePlay = common_vendor.ref(true);
    const videoContent = common_vendor.ref(null);
    videoContent.value = common_vendor.index.createVideoContext("video1");
    const TxvContext = requirePlugin("tencentvideo");
    let txvContext;
    let count = 0;
    common_vendor.onMounted(() => {
    });
    function onVideoTimeUpdate(e) {
      if (advReward.value.status == 0 || !advReward.value.status) {
        count++;
      }
      if (count == 0) {
        if (e.detail.currentTime > advReward.value.time) {
          videoContent.value.pause();
          agreePlay.value = false;
        }
        if (!agreePlay.value) {
          popupVisible.value = true;
        }
      }
    }
    function onTenTimeUpdate(e) {
      console.log(txvContext, "腾讯");
      if (advReward.value.status == 0 || !advReward.value.status) {
        count++;
      }
      if (count == 0) {
        if (e.detail.currentTime > advReward.value.time) {
          txvContext.pause();
          agreePlay.value = false;
        }
        if (!agreePlay.value) {
          popupVisible.value = true;
        }
      }
    }
    common_vendor.onReady(() => {
    });
    function createReward() {
      if (common_vendor.wx$1.createRewardedVideoAd) {
        if (rewardAdv.value) {
          rewardAdv.value = null;
        }
        rewardAdv.value = common_vendor.wx$1.createRewardedVideoAd({ adUnitId: advReward.value.id });
        rewardAdv.value.onLoad(() => {
          console.log("激励广告加载成功");
          console.log("onLoad event emit");
        });
        rewardAdv.value.onError((err) => {
          console.log("onError event emit", err);
          agreePlay.value = true;
          console.log("下发奖励");
          console.log("播放");
          if (videoContent.value) {
            videoContent.value.play();
          }
          if (txvContext) {
            txvContext.play();
          }
          count++;
        });
        rewardAdv.value.onClose((res) => {
          console.log("onClose event emit", res);
          if (res && res.isEnded) {
            agreePlay.value = true;
            console.log("下发奖励");
            console.log("播放");
            if (videoContent.value) {
              videoContent.value.play();
            }
            if (txvContext) {
              txvContext.play();
            }
            count++;
          }
        });
      }
    }
    function showReward() {
      console.log(111);
      rewardAdv.value.show().catch(() => {
        rewardAdv.value.load().then(() => rewardAdv.value.show()).catch((err) => {
          console.log("激励视频广告显示失败");
          rewardAdv.value.load().then(() => rewardedVideoAd.show()).catch((err2) => {
            console.log("激励视频 广告显示失败");
          });
        });
      });
    }
    function cancelPop() {
      popupVisible.value = false;
    }
    function enterPop() {
      popupVisible.value = false;
      showReward();
    }
    function playVideo() {
      if (agreePlay.value)
        ;
      else {
        videoContent.value.pause();
        popupVisible.value = true;
      }
    }
    common_vendor.onLoad((res) => {
      isFromShare.value = res.share;
      backPage.value = res.backPage;
      id.value = res.id - 0;
      if (!id.value) {
        common_vendor.index.switchTab({
          url: "/pages/index/index"
        });
      }
    });
    function f_getVideoInfo(o) {
      utils_api.videoInfo(o).then((data) => {
        console.log("newInfo", data);
        num.value.read = data.xcxVideo.readNum + data.xcxVideo.playNum;
        num.value.like = data.xcxVideo.playNum;
        isLike.value = data.xcxVideo.status - 0;
        vid.value = data.xcxVideo.videoUrl;
        videoSrc.value = data.xcxVideo.video;
        title.value = data.xcxVideo.title;
        updataTime.value = data.xcxVideo.createTime;
        suggestList.value = data.recommends;
        if (suggestList.length > 0) {
          suggestList.value.forEach((item) => {
            item.icon = item.icon.split(",")[0];
          });
        }
        if (vid.value) {
          setTimeout(() => {
            txvContext = TxvContext.getTxvContext("txv");
          }, 200);
        }
      });
    }
    const advT = common_vendor.ref({
      status: null,
      every: null,
      advId: null,
      type: null
    });
    const advB = common_vendor.ref({
      status: null,
      every: null,
      advId: null,
      type: null
    });
    const advC = common_vendor.ref({
      status: null,
      advId: null,
      intervalNum: null
    });
    const timer = common_vendor.ref(null);
    let interstitialAd = null;
    function showAdv1() {
      if (interstitialAd) {
        interstitialAd.show().then(() => {
          console.log("插屏广告显示中，不再定时拉取广告");
        }).catch((err) => {
          console.error(err);
        });
      }
    }
    const createAdv1 = function() {
      if (common_vendor.wx$1.createInterstitialAd) {
        interstitialAd = common_vendor.wx$1.createInterstitialAd({
          adUnitId: advC.value.advId
        });
        interstitialAd.onLoad(() => {
          console.log("onLoad event emit");
        });
        interstitialAd.onError((err) => {
          console.log("onError event emit", err);
        });
        interstitialAd.onClose((res) => {
          console.log("插屏广告已关闭，重新开始定时拉取");
          if (!timer) {
            timer.value = setInterval(() => {
              console.log(2);
              showAdv1();
            }, advC.value.intervalNum * 1e3);
            console.log("onClose event emit", res);
          }
        });
        timer.value = setInterval(() => {
          console.log(1);
          showAdv1();
          clearInterval(timer.value);
        }, advC.value.intervalNum * 1e3);
      }
    };
    function f_getAdv(o) {
      utils_api.Adv(o).then((res) => {
        let typeT = null;
        let typeB = null;
        res.advertPlaceConfigs.forEach((element) => {
          if (element.title == "top_vid") {
            typeT = element.advertTypeId;
            advT.value.status = element.status;
            advT.value.every = element.acticleCnt;
            advT.value.type = element.advertTypeId;
          }
          if (element.title == "bottom_vid") {
            typeB = element.advertTypeId;
            advB.value.status = element.status;
            advB.value.every = element.acticleCnt;
            advB.value.type = element.advertTypeId;
          }
        });
        res.advertTypes.forEach((element) => {
          if (typeT == element.type) {
            advT.value.advId = element.content.trim();
          }
          if (typeB == element.type) {
            advB.value.advId = element.content.trim();
          }
          if (element.type == 2) {
            advC.value.status = element.status;
            advC.value.advId = element.content.trim();
            advC.value.interval = element.intervalNum;
          }
          if (element.type == 4) {
            advReward.value.id = element.content.trim();
            advReward.value.time = element.intervalNum;
            advReward.value.title = element.title;
            advReward.value.status = element.status;
            createReward();
          }
        });
        if (advC.value.status) {
          createAdv1();
        }
      });
    }
    common_vendor.onShow(() => {
      f_getAdv({
        appId: appId.value
      });
      common_vendor.wx$1.hideShareMenu({
        menus: ["shareTimeline"]
      });
    });
    common_vendor.onHide(() => {
      utils_adv.clearTimer();
      clearInterval(timer.value);
      interstitialAd = null;
      rewardAdv.value = null;
    });
    common_vendor.onUnload(() => {
      utils_adv.clearTimer();
      clearInterval(timer.value);
      interstitialAd = null;
      rewardAdv.value = null;
    });
    common_vendor.onMounted(() => {
      if (sign.value) {
        f_getVideoInfo({
          id: id.value,
          appId: appId.value
        });
      }
    });
    function f_refresh(item) {
      f_getVideoInfo({
        id: item.id,
        appId: appId.value
      });
    }
    common_vendor.onShareAppMessage(() => {
      return {
        title: title.value,
        path: "/pages/index/index?path=/pages_details/video_details/video_details&type=noTabBar&share=true&backPage=/pages/video/video&id=" + id.value
      };
    });
    return (_ctx, _cache) => {
      return common_vendor.e({
        a: common_vendor.p({
          name: title.value,
          back: true,
          isShare: isFromShare.value,
          backPage: backPage.value
        }),
        b: advT.value.status == 1 && advT.value.advId && advT.value.type == 1
      }, advT.value.status == 1 && advT.value.advId && advT.value.type == 1 ? {
        c: advT.value.advId
      } : {}, {
        d: advT.value.status == 1 && advT.value.advId && advT.value.type == 3
      }, advT.value.status == 1 && advT.value.advId && advT.value.type == 3 ? {
        e: advT.value.advId
      } : {}, {
        f: common_vendor.t(title.value),
        g: common_vendor.t(updataTime.value),
        h: !vid.value
      }, !vid.value ? {
        i: "https://xcx.wujingchuanmei.com/api" + videoSrc.value,
        j: common_vendor.o(($event) => onVideoTimeUpdate($event)),
        k: common_vendor.o(playVideo)
      } : {
        l: common_vendor.o(onTenTimeUpdate),
        m: vid.value,
        n: common_vendor.o(playVideo)
      }, {
        o: common_vendor.t(num.value.read),
        p: common_vendor.p({
          name: "logo-wechat",
          size: "48rpx"
        }),
        q: common_vendor.p({
          name: "logo-wechat",
          size: "48rpx"
        }),
        r: advB.value.status == 1 && advB.value.advId && advB.value.type == 1
      }, advB.value.status == 1 && advB.value.advId && advB.value.type == 1 ? {
        s: advB.value.advId
      } : {}, {
        t: advB.value.status == 1 && advB.value.advId && advB.value.type == 3
      }, advB.value.status == 1 && advB.value.advId && advB.value.type == 3 ? {
        v: advB.value.advId
      } : {}, {
        w: suggestList.value
      }, suggestList.value ? {
        x: common_vendor.f(suggestList.value, (item, index, i0) => {
          return {
            a: "ffd1c306-4-" + i0,
            b: common_vendor.p({
              src: "https://xcx.wujingchuanmei.com/api" + item.icon,
              mode: "aspectFill",
              shape: "round",
              ariaLabel: "img"
            }),
            c: common_vendor.t(item.title),
            d: common_vendor.o(($event) => f_refresh(item), index),
            e: index
          };
        })
      } : {}, {
        y: common_vendor.p({
          name: "视频"
        }),
        z: popupVisible.value
      }, popupVisible.value ? {
        A: common_vendor.t(advReward.value.title),
        B: common_vendor.o(cancelPop),
        C: common_vendor.o(enterPop)
      } : {});
    };
  }
});
const MiniProgramPage = /* @__PURE__ */ common_vendor._export_sfc(_sfc_main, [["__file", "C:/Users/Administrator/Desktop/new(1)/new/pages_details/video_details/video_details.vue"]]);
_sfc_main.__runtimeHooks = 6;
wx.createPage(MiniProgramPage);
